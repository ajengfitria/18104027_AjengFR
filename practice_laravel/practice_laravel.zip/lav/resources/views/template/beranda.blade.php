@extends('template.base')
@section('content')
	<h1>Beranda</h1>
@endsection