
<?php $__env->startSection('content'); ?>
	<h1>Beranda</h1>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\prakweb\18104027_AjengFR\practice_laravel\lav\resources\views/template/beranda.blade.php ENDPATH**/ ?>