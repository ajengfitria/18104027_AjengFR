
<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-lg-12">
        <!-- <?php if(session()->has('pesan')): ?>
        <div class="alert alert-success">
            <?php echo e(session()->get('pesan')); ?>

        </div>
        <?php endif; ?> -->
        <a href="<?php echo e(route('student.create')); ?>" class="btn btn-primary mb-2">Tambah</a>
        <div class="table-responsive">
            <table class="table table-striped data-table">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>NIM</th>
                        <th>Name</th>
                        <th>Gender</th>
                        <th>Jurusan</th>
                        <th>Alamat</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>

                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script>
    $('.data-table').DataTable({
        processing: true,
        serverSide: true,
        ajax: "<?php echo e(route('student.data')); ?>",
        columns: [
            {
                data: 'DT_RowIndex',
                name: 'DT_RowIndex',
            },
            {
                data: 'nim',
                name: 'nim',
            },
            {
                data: 'name',
                name: 'name',
            },
            {
                data: 'gender',
                name: 'gender',
            },
            {
                data: 'departement',
                name: 'departement',
            },
            {
                data: 'address',
                name: 'address',
            },
            {
                data: 'action',
                name: 'action',
            },
        ]
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\prakweb\18104027_AjengFR\practice_laravel\lav\resources\views/template/student_data.blade.php ENDPATH**/ ?>