
<?php $__env->startSection('content'); ?>
	<h1>About</h1>
	<p>Ini adalah Praktikum pemrograman web yang mempelajari Framework PHP yaitu Laravel</p>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\prakweb\18104027_AjengFR\practice_laravel\resources\views/template/about.blade.php ENDPATH**/ ?>